package com.cg.labOne2;

public class Sbu {
	private String sbuName, sbuHead, sbuCode;

	public Sbu(String sbuName, String sbuHead, String sbuCode) {
		super();
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
		this.sbuCode = sbuCode;
	}

	@Override
	public String toString() {
		return "Sbu [sbuName=" + sbuName + ", sbuHead=" + sbuHead + ", sbuCode=" + sbuCode + "]";
	}
	
	

}
