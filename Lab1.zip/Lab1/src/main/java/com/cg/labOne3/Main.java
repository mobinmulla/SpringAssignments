package com.cg.labOne3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("employeeLab1-3.xml");
		Sbu sbu = context.getBean(Sbu.class);
		
		System.out.println(sbu);
		
		
	}

}
