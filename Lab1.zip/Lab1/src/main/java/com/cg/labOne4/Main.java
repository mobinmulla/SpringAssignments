package com.cg.labOne4;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("employeeLab1-4.xml");
		Employee employee = (Employee) context.getBean("emp");
		
		Scanner input = new Scanner(System.in);
		int choice;
		System.out.println("Enter Employee ID:");
		choice = input.nextInt();
		
		if(choice == employee.getEmpId()) {
			System.out.println(employee);
		}else {
			System.out.println("Employee Data not found");
		}

		
	}
}
